export class Employee {
    id?: number;
    name: string;
    designation: string;
    salary: number;
}
