const employeeData = [
    {
        id: 0,
        name: 'Urvesh',
        designation: 'Software Dev',
        salary: 10000
    },
    {
        id: 1,
        name: 'Riya',
        designation: 'Admin',
        salary: 5000
    },
    {
        id: 2,
        name: 'Vikram',
        designation: 'Business Analyst',
        salary: 15000
    },
    {
        id: 3,
        name: 'Yogesh',
        designation: 'CEO',
        salary: 75000
    },
    {
        id: 4,
        name: 'Sapna',
        designation: 'HR',
        salary: 12500
    }
];
